# coding=utf-8

###### Options ######

options={}

options["<config>"]=ur'Default'
options["<os>"]=ur'android'
options["appdata"]=ur'C:/Users/Arfelon/AppData/Roaming/MarmaladeTools'
options["build"]=ur'ARM GCC Release'
options["cmdline"]=['C:/Marmalade/7.3/s3e/makefile_builder/mkb.py', 'c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage2/Stage2.mkb', '--default-buildenv=vc10', '--msvc-project', '--deploy-only']
options["device"]=ur'"{"localdir}/Deploy.py" device "{"tempdir}/DeployOpts.py" {hasmkb}'
options["dir"]=ur'c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage2/build_stage2_vc10'
options["folder"]=ur'"{"localdir}/Deploy.py" folder "{"tempdir}/DeployOpts.py" {hasmkb}'
options["hasmkb"]=ur'nomkb'
options["helpfile"]=ur'../docs/Deployment.chm'
options["helppage"]=ur'0'
options["lastdir"]=ur'c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage7/build_stage7_vc12x'
options["mkb"]=ur'c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage2/Stage2.mkb'
options["mkbdir"]=ur'c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage2'
options["mkbfile"]=ur'Stage2.mkb'
options["outdir"]=ur'c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage2/build_stage2_vc10'
options["resdir"]=ur'c:/marmalade/7.3/tools/DeployTool/'
options["s3edir"]=ur'c:/marmalade/7.3/s3e/'
options["stage"]=ur''
options["target"]=ur'Stage2'
options["task"]=ur'Default'
options["tasktype"]=ur'Package and Install'

###### Tasks ######

tasks=[]

### Task Default:android ###

t={}
tasks.append(t)
t["tasktype"]="Package and Install"
t["<config>"]="Default"
t["os"]="android"
t["endDir"]="c:/Marmalade/7.3/examples/GameTutorial/CPP/Stage2/build_stage2_vc10/deployments/default/android/release/arm"
